﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 13_spectra_granodiorite_rock

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in SÚRO office, 2nd floor
- granodiorite rock - coarse-grained intrusive igneous rock similar to granite, known for containing higher amounts of natural radionuclides (K, U, Th) and thus having radioactivity above common natural background
- RadiaCode in a plastic bag placed directly on the stone, measured in the Sporilov Geopark
https://www.ig.cas.cz/en/outreach/geopark-prague/

data acquisition time:
- background: ~ 1 hour
- granodiorite: ~10 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz