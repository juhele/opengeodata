Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 11_spectra_EG_3X_source_Am-241

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- Am-241 radionuclide source (instrument check source) from Czech metrology institute (Czech: �esk� metrologick� institut, �MI), in 10 cm distance from the detector
- product catalogue (Czech only):
https://www.cmi.cz/sites/all/files/public/download/katalog_OI%20Praha_2015_%C4%8Desky.pdf
- Am-241, type: EG 3X, activity: 864.5 kBq, reference date: 1.7. 2015

data acquisition time:
- background: ~ 1 hour
- Am-241: ~10 min, ~15 min, ~30 min, ~1 hour

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz