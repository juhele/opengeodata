Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 01_spectra_natural_background

instrument: RadiaCode-101

description: 
- spectra "office" - measured in S�RO office, 2nd floor
- spectra "outside" - detector (in plastic bag) laid on the lawn in the garden
- natural background

data acquisition time:
- "office": ~ 20 min, ~ 1 hour
- "outside": ~40 min, ~50 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz