Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 06_spectra_Jachymov_Retizkarna

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- the other spectra were measured in J�chymov, in the area of former uranium mine and labor camp Rovnost (English "Equality"), some photos here: https://flic.kr/s/aHBqjzPg5g
- the name comes from Czech "�et�zk�rna" - nickname for the building of the former chain locker room
- some spectra are from the building, one from the road in front of it, another from the Hotel Berghof garden

data acquisition time:
- background: ~ 1 hour
- field measurements: ~3-12 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz