﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 14_spectra_thorium-rich_material

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in SÚRO office, 2nd floor
- thorium rich material - by-product of titanium dioxide (also known as "titanium white") production using ilmenite mineral (FeTiO3) and sulfate process
- this material could be defined as Naturally occurring radioactive material (NORM) or technologically enhanced naturally occurring radioactive material (TENORM)
- ilmenite is known to also contain natural radionuclides like Uranium-238 and Thorium-232
- sample in 10 cm distance from the detector

data acquisition time:
- background: ~ 1 hour
- thorium material: ~10 min, ~1 hour, ~2 hours

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

-----------------------------------------
References:

https://en.wikipedia.org/wiki/Titanium_dioxide
https://en.wikipedia.org/wiki/Ilmenite
https://en.wikipedia.org/wiki/Naturally_occurring_radioactive_material

Measurement of 238U and 232Th radionuclides in ilmenite and synthetic rutile
M I Idris et al 2018 IOP Conf. Ser.: Mater. Sci. Eng. 298 012010
https://iopscience.iop.org/article/10.1088/1757-899X/298/1/012010/pdf

Haridasan PP, Pillai PM, Tripathi RM, Puranik VD. Thorium in ilmenite and its radiological implications in the production of titanium dioxide. Radiat Prot Dosimetry. 2008;129(4):381-5. doi: 10.1093/rpd/ncm446. Epub 2007 Oct 19. PMID: 17951239.
https://pubmed.ncbi.nlm.nih.gov/17951239/