Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 09_spectra_EG_3X_source_Co-60

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- Co-60 radionuclide source (instrument check source) from Czech metrology institute (Czech: �esk� metrologick� institut, �MI), in 10 cm distance from the detector
- product catalogue (Czech only):
https://www.cmi.cz/sites/all/files/public/download/katalog_OI%20Praha_2015_%C4%8Desky.pdf
- Co-60, type: EG 3X, activity: 807.7 kBq, reference date: 1.7. 2015

data acquisition time:
- background: ~ 1 hour
- Co-60: ~10 min, ~1 hour

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz