Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 16_spectra_EG_3X_source_Co-57

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- Co-57 radionuclide source (instrument check source) from Czech metrology institute (Czech: �esk� metrologick� institut, �MI), in 10 cm distance from the detector
- product catalogue (Czech only):
https://www.cmi.cz/sites/all/files/public/download/katalog_OI%20Praha_2015_%C4%8Desky.pdf
- Co-57, type: EG 3X, activity: 495.2 kBq, reference date: 30.12. 2017

data acquisition time:
- background: ~ 1 hour
- Co-57: ~10 min, ~1 hour, ~3 hours

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz