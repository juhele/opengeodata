Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 04_spectra_uranium_glass

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- an object made of currently produced uranium glass (also nicknamed "Vaseline glass")
- according to the information from the State Office for Nuclear Safety (S�JB) currently produced uranium glass in the Czech Republic should not contain more than 1% uranium:
Problematika uranem barven�ho skla
https://www.sujb.cz/radiacni-ochrana/oznameni-a-informace/problematika-uranem-barveneho-skla

data acquisition time:
- background: ~ 1 hour
- uranium glass: ~10 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz