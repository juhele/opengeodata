Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 03_spectra_potassium_fertilizer

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- commercial potassium fertilizer from garden centre
- approximately 0.01% of potassium is radioactive potassium isotope K-40
- depending on the type, the activity of K-40 in the fertilizer is approximately in the range of 2.5 - 7.7 kBq / kg
- check K-40 peak at 1460.8 keV

data acquisition time:
- background: ~ 1 hour
- potassium fertilizer: ~12 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz