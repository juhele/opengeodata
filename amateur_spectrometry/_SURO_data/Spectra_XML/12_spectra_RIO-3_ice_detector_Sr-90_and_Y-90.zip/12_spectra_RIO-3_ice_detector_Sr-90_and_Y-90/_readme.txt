﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 12_spectra_RIO-3_ice_detector_Sr-90_and_Y-90

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in SÚRO office, 2nd floor
- RIO-3 (РИО-3) type ice detector with radioactive material (Strontium 90) used in aviation (for example for Mi-8/Mi-17 helicopters), measured in 10 cm distance from the detector
- information in Russian:
Сигнализатор обледенения
https://ru.wikipedia.org/wiki/%D0%A1%D0%B8%D0%B3%D0%BD%D0%B0%D0%BB%D0%B8%D0%B7%D0%B0%D1%82%D0%BE%D1%80_%D0%BE%D0%B1%D0%BB%D0%B5%D0%B4%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F

data acquisition time:
- background: ~ 1 hour
- RIO-3: ~10 min, ~20 min

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz