Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 15_spectra_EG_3_source_Ba-133

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- Ba-133 radionuclide source (instrument check source) from Czech metrology institute (Czech: �esk� metrologick� institut, �MI), in 10 cm distance from the detector
- product catalogue (Czech only):
https://www.cmi.cz/sites/all/files/public/download/katalog_OI%20Praha_2015_%C4%8Desky.pdf
- Ba-133, type: EG 3, activity: 82.36 kBq, reference date: 30.12. 2017

data acquisition time:
- background: ~ 1 hour
- Ba-133: ~10 min, ~1 hour

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz