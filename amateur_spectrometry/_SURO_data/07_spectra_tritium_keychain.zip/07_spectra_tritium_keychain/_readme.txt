Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 07_spectra_tritium_keychain

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- commercially avalable tritium keychain "nite GlowRing" - transparent plastic case contains sealed borosilicate glass vial with internal surface coated with a phosphor-containing material and filled with tritium gas, the beta particles from the tritium decay interact with the coating and produce visible glow 
- it is called GTLS ("gaseous tritium light source")
- the beta radiation is not able to pass through the glass wall, but GTLS devices do emit low levels of X-rays due to bremsstrahlung:
"Gaseous tritium light sources (GTLSs) and gaseous tritium light devices (GTLDs)" (PDF). Radiation Safety Handbook. Ministry of Defence (United Kingdom). May 2009. JSP 392.
https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/946070/JSP_392_Chapter_19_-_GTLS_-GTLD__Alt_Text_.pdf

data acquisition time:
- background: ~ 1 hour
- field measurements: ~1 hour, ~4 hours

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz