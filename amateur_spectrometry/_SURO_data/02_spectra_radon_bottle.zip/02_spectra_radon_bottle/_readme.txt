Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were performed within the research topic of institutional support provided by the Ministry of the Interior of the Czech Republic
-------------------------------------------------------------------------------------------------------------

data: 02_spectra_radon_bottle

instrument: RadiaCode-101

description: 
- background spectrum "Background - office 1 hour" - measured in S�RO office, 2nd floor
- radon in common plastic bottle
- radon itself is a source of alpha radiation, but in the spectrum we detect its decay products ("radon daughters") - radioactive isotopes of Bi, Po, Pb

data acquisition time:
- background: ~ 1 hour
- radon bottle: ~10 min, ~20 min, ~1 hour

- data source for citation etc.:

National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz