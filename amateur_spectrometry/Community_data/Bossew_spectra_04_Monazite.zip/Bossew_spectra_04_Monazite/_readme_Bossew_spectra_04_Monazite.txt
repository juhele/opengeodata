﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were kindly provided by Peter Bossew

https://www.researchgate.net/scientific-contributions/Peter-Bossew-39092361
https://orcid.org/0000-0003-3924-8815
-------------------------------------------------------------------------------------------------------------

data: Bossew_spectra_04_Monazite

instrument: RadiaCode-101

description: 
- background spectrum "Background-W-2" ~ 5 days
- samples - monazite (Ce,La,Th)PO4 (1) from 
Guarapari, Brazil
Kerala, India
Sri Lanka 

data acquisition time:
- background: ~ 5 days
- monazite (Ce,La,Th)PO4 from Guarapari, Brazil ~ 10 minutes measurement 
- monazite (Ce,La,Th)PO4 from Kerala, India ~ 15 minutes measurement
- monazite (Ce,La,Th)PO4 from Sri Lanka ~ 66 minutes measurement 

(1) https://en.wikipedia.org/wiki/Monazite
