﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were kindly provided by Peter Bossew

https://www.researchgate.net/scientific-contributions/Peter-Bossew-39092361
https://orcid.org/0000-0003-3924-8815
-------------------------------------------------------------------------------------------------------------

data: Bossew_spectra_03_Schlackenstein

instrument: RadiaCode-101

description: 
- background spectrum "Background1" ~ 12 hours
- Copper slag material "Mansfelder Kupferschlacke" containing natural radionuclides (more in German - see Wikipedia article (1)) - Ra-226, Th-232, K-40; classified as technologically enhanced naturally occurring radioactive materials (TENORM)

data acquisition time:
- background: ~ 12 hours
- Danube sediment: ~ 20 hours

(1) https://de.wikipedia.org/wiki/Mansfelder_Kupferschlackensteine
