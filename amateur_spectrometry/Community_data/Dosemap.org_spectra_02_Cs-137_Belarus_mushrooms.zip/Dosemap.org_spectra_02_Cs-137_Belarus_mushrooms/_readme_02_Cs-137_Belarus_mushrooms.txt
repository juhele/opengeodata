﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were obtained from the Dosemap.org website
-------------------------------------------------------------------------------------------------------------

data: Dosemap.org_spectra_02_Cs-137_Belarus_mushrooms

source data link: https://dosemap.org/info/cs137-nalibokskaya-pushcha/

instrument: RadiaCode-101

description: 
- background spectrum "Background17d" ~ 17 days
- Cs-137 in mushrooms collected in the area of Nalibokskaya Pushcha (Naliboki forest), Volozhin, Belarus
- info: https://en.wikipedia.org/wiki/Naliboki_forest

data acquisition time:
- background: ~ 17 days
- mushrooms: ~13 days

source data description:

RU:
Cs-137 / Грибы Налибокская пуща, Воложин, Беларусь
Содержит изотопы: 137Cs
Грибы, собранные в районе Налибокской пущи, г. Воложин, Беларусь
Спектр в формате RadiaCode-101 / Becquerel Monitor

EN:

Cs-137 / Mushrooms Nalibokskaya Pushcha, Volozhin, Belarus
Contains isotopes: 137Cs
Mushrooms collected in the area of Nalibokskaya Pushcha, Volozhin, Belarus
137Cs (mushrooms, Belarus) - RadiaCode-101
Spectrum in RadiaCode-101 / Becquerel Monitor format