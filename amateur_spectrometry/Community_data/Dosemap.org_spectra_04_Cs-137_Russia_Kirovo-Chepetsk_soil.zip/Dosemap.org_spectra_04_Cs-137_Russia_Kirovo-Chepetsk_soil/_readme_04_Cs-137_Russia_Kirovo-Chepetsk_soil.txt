﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were obtained from the Dosemap.org website
-------------------------------------------------------------------------------------------------------------

data: Dosemap.org_spectra_04_Cs-137_Russia_Kirovo-Chepetsk_soil

source data link: https://dosemap.org/info/cs137-ground-chepetsk_3/

instrument: RadiaCode-101

description: 
- background spectrum "Background, place of sample measurement" ~ 7.8 days
- Cs-137 in soil sample collected near Elkhovka River (Reka Yelkhovka), Kirovo-Chepetsk (58.55188N, 49.90925E)

data acquisition time:
- background: ~ 7.8 days
- soil sample: ~ 5.2 days

source data description:

RU:
Cs-137 / Проба грунта #3 / Кирово-Чепецк
Содержит изотопы: 137Cs
Грунт после подготовки (измельчение и сушка)
1. RadiaCode-101
Проба грунта, река Елховка г. Кирово-Чепецк, результат нарушения целостности хранилища ядерных отходов
https://dosemap.org/#58.55188,49.90925,18z
137Cs — спектр непосредственно в точке отбора пробы, RadiaCode-101
Проба грунта, длительное измерение, сосуд маринелли 1 литр
Спектр в формате RadiaCode-101 / Becquerel Monitor

EN:
Cs-137 / Soil sample #3 / Kirovo-Chepetsk
Contains isotopes: 137Cs
Soil after preparation (grinding and drying)
1. RadiaCode-101
Soil sample, Elkhovka River, Kirovo-Chepetsk, the result of a violation of the integrity of the nuclear waste storage facility
https://dosemap.org/#58.55188,49.90925,18z
137Cs - spectrum directly at the sampling point, RadiaCode-101
Soil sample, long-term measurement, Marinelli vessel 1 liter
Spectrum in RadiaCode-101 / Becquerel Monitor format