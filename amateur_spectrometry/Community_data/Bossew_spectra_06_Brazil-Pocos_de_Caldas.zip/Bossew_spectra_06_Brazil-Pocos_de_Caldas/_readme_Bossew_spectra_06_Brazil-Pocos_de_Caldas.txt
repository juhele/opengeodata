﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were kindly provided by Peter Bossew

https://www.researchgate.net/scientific-contributions/Peter-Bossew-39092361
https://orcid.org/0000-0003-3924-8815
-------------------------------------------------------------------------------------------------------------

data: Bossew_spectra_06_Brazil-Pocos_de_Caldas

instrument: RadiaCode-101

description: 
- background spectrum "Background-W-2" ~ 5 days
- caldasite sample - an uraniferous zirconium ore, a mixture of Zircon (ZrSiO4) and Baddeleyite (ZrO2), with an average zirconium content higher than 60% ZrO2- and uranium content of 0.3 % U3O8
- samples from Morro do Ferro (Poços de Caldas, Brazil) uranium deposit


data acquisition time:
- background: ~ 5 days
- caldasite: ~ 77 minutes
- Morro do Ferro samples: ~ 42 minutes

(1) https://www.mindat.org/show.php?id=4714
