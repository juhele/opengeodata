﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were obtained from the Dosemap.org website
-------------------------------------------------------------------------------------------------------------

data: Dosemap.org_spectra_01_Cs-137_OSGI_source

source data link: https://dosemap.org/info/cs137-osgi/

instrument: RadiaCode-101

description: 
- background spectrum "Combined background" ~ 55 days
- Cs-137 radionuclide source (instrument check source) OSGI / ОСГИ

data acquisition time:
- background: ~ 55 days
- Cs-137: ~10 min

source data description:

RU:
Cs-137 / Контрольный источник ОСГИ
Содержит изотопы: 137Cs
Спектр RadiaCode-101

EN:
Cs-137 / Control source OSGI
Contains isotopes: 137Cs
RadiaCode-101 spectrum