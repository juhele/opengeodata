﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were kindly provided by Peter Bossew

https://www.researchgate.net/scientific-contributions/Peter-Bossew-39092361
https://orcid.org/0000-0003-3924-8815
-------------------------------------------------------------------------------------------------------------

data: Bossew_spectra_05_Uranium_glass_and_uraninite

instrument: RadiaCode-101

description: 
- background spectrum "Background-W-2" ~ 5 days
- uranium glass
- uraninite mineral (UO2)

data acquisition time:
- background: ~ 5 days
- uranium glass: ~ 40 min
- uraninite mineral (UO2): ~ 12 37 min

(1) https://en.wikipedia.org/wiki/Uranium_glass
(2) https://en.wikipedia.org/wiki/Uraninite
