﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were obtained from the Dosemap.org website
-------------------------------------------------------------------------------------------------------------

data: Dosemap.org_spectra_03_Cs-137_Russia_Kirovo-Chepetsk_soil

source data link: https://dosemap.org/info/cs137-ground-chepetsk/

instrument: RadiaCode-101

description: 
- background spectrum "Background, place of sample measurement" ~ 8 days
- Cs-137 in soil sample collected near Lake Prosnoe, Kirovo-Chepetsk (58.5436389N, 49.8945833E)

data acquisition time:
- background: ~ 8 days
- soil sample: ~ 3 days

source data description:

RU:
Cs-137 / Проба грунта #2 / Кирово-Чепецк
Содержит изотопы: 137Cs
1. RadiaCode-101
Проба грунта возле озера Просное, г. Кирово-Чепецк, результат нарушения целостности хранилища ядерных отходов
https://dosemap.org/#58.543634,49.89458,18z
Активность 137Cs в пробе грунта около оз. Просное — RadiaCode-101
Спектр в формате RadiaCode-101 / Becquerel Monitor

EN:
Cs-137 / Soil sample #2 / Kirovo-Chepetsk
Contains isotopes: 137Cs
1. RadiaCode-101
Soil sample near Lake Prosnoe, Kirovo-Chepetsk, the result of a violation of the integrity of the nuclear waste storage facility
https://dosemap.org/#58.543634,49.89458,18z
The activity of 137Cs in the soil sample near the lake Prosnoe - RadiaCode-101
Spectrum in RadiaCode-101 / Becquerel Monitor format