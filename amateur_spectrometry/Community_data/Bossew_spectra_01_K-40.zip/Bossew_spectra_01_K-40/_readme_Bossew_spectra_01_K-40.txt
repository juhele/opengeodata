﻿Amateur gamma spectrometry with pocket spectrometer RadiaCode-101
https://github.com/juhele/opengeodata/tree/master/amateur_spectrometry
-------------------------------------------------------------------------------------------------------------

These measurements were kindly provided by Peter Bossew

https://www.researchgate.net/scientific-contributions/Peter-Bossew-39092361
https://orcid.org/0000-0003-3924-8815
-------------------------------------------------------------------------------------------------------------

data: Bossew_spectra_01_K-40

instrument: RadiaCode-101

description: 
- background spectrum "background" ~ 12 hours
- K-40 - food-grade potassium chloride (KCl, or potassium salt)

data acquisition time:
- background: ~ 12 hours
- K-40: ~ 16 hours