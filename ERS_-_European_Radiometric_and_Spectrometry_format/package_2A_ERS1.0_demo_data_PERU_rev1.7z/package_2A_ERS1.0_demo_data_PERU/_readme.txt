package_2A_ERS1.0_demo_data_PERU

ERS (European Radiometric and Spectrometry format) data for software development and testing
- ERS version 1.0
- for more information about the format see this document:

Bucher B, Guillot L, Strobl C, Butterweck G, Gutierrez S, Thomas M, Hohmann C, Krol I, Rybach L, Schwarz G. International intercomparison exercise of airborne gammaspectrometric systems of Germany, France and Switzerland in the framework of the Swiss Exercise ARM07. Villigen, Switzerland: Paul Scherrer Institut PSI; 2009. 130p. PSI Bericht Nr. 09-07.

available here:
http://www.lib4ri.ch/archive/nebis/PSI_Berichte_000478272/PSI-Bericht_09-07_2D.pdf
or:
https://inis.iaea.org/collection/NCLCollectionStore/_Public/41/030/41030200.pdf

About the data:
- real data, but changed location, date and time information
- made almost manually using QGIS (1), LibreOffice (2) and Notepad++ (3)

- location of the testing data is now the Nazca Plain in Peru, known for the lines and geoglyphs - see:

https://en.wikipedia.org/wiki/Nazca_Lines

- supplied preview image uses map background from:
Sentinel-2 cloudless - https://s2maps.eu by EOX IT Services GmbH (Contains modified Copernicus Sentinel data 2016 & 2017)

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org