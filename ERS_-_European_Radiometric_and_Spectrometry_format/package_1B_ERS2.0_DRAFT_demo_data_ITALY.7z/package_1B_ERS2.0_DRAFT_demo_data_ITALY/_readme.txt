package_1B_ERS2.0_demo_data_ITALY

ERS (European Radiometric and Spectrometry format) data for software development and testing
- ERS version 2.0
- for more information about the format see this document:

Butterweck, G., Bucher, B., Gryc, L., Debayle, C., Strobl, C.,  Maillard, S., Thomas, M., Helbig, A., Krol, I., Chuzel, S., Couvez, C., Ohera, M., Rybach, L., Poretti, C.,  Hofstetter-Boillat, B., Mayer, S., Scharding, G.: International Intercomparison Exercise of Airborne Gamma-Spectrometric Systems of the Czech Republic, France, Germany and Switzerland in the Framework of the Swiss Exercise ARM17. PSI-Report No. 18-04, ISSN 1019-0643, Paul Scherrer Institut, Villigen, Switzerland, 2018.

available here:
https://www.researchgate.net/publication/330482739_International_Intercomparison_Exercise_of_Airborne_Gamma-Spectrometric_Systems_of_the_Czech_Republic_France_Germany_and_Switzerland_in_the_Framework_of_the_Swiss_Exercise_ARM17

About the data:
- real data, but changed location, date and time information
- made almost manually using QGIS (1), LibreOffice (2) and Notepad++ (3)

- supplied preview image uses map background from:
Sentinel-2 cloudless - https://s2maps.eu by EOX IT Services GmbH (Contains modified Copernicus Sentinel data 2016 & 2017)
- the detailed one has background from Bing Aerial via QGIS OpenLayers plugin

- location of the testing data is now the Vulcano island in Italy:

Vulcano (Sicilian: Vurcanu) or "Vulcan" is a small volcanic island in the Tyrrhenian Sea, about 25 km (16 mi) north of Sicily and located at the southernmost end of the eight Aeolian Islands.[1] The island is 21 km2 (8 sq mi) in area, rises to 501 m (1,644 ft) above sea level, and it contains several volcanic caldera, including one of the four active volcanoes in Italy that are not submarine. The word "volcano" and its equivalent in several European languages derive from the name of this island, which in turn derives from Vulcan, the Roman god of fire.

(source: https://en.wikipedia.org/wiki/Vulcano )

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org