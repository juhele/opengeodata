ERS vector layer styles in QGIS QML / SLD format

web: https://github.com/juhele/opengeodata/tree/master/ERS_-_European_Radiometric_and_Spectrometry_format

prepared by Jan Helebrant
jan.helebrant@suro.cz
National Radiation Protection Institute (S�RO)? Prague, Czech Republic
www.suro.cz