package_1__source_demo_data_ITALY

These are the source data used to create the ERS files for "package_1A_ERS1.0_demo_data_ITALY"

Coordinates:
- standard WGS84 EPSG:4326 coordinate system
http://spatialreference.org/ref/epsg/4326/
- coordinates in decimal degrees

PE_longitude_deg ... x
PN_latitude_deg ... y

- PE and PN definition from PSI Bericht Nr. 09-07 (link and full citation below):

"PN ... Measurement or sample point coordinate N-S (latitude) Negative values allowed, when appropriate. 
If used for Earth centred coordinates (X, Y and Z), PN corresponds to Y)"

"PE ... Measurement or sample point coordinate E-W (longitude) Negative values allowed, when appropriate.
If used for Earth centred coordinates (X, Y and Z), PE corresponds to X)"

The file contain all the data columns used in the ERS file with some additional ones:

1) "DHSR_uSvph" and "DHSR_uSvps" instead of "DHSR"

- ERS 1.0 has "DHSR" in microSv/s
- ERS 2.0 has "DHSR" in microSv/h

2) "TC_CPS"

- total count = the sum of all the spectral channels



------------ about ERS data format ------------

ERS (European Radiometric and Spectrometry format) data for software development and testing
- ERS version 1.0
- for more information about the format see this document:

Bucher B, Guillot L, Strobl C, Butterweck G, Gutierrez S, Thomas M, Hohmann C, Krol I, Rybach L, Schwarz G. International intercomparison exercise of airborne gammaspectrometric systems of Germany, France and Switzerland in the framework of the Swiss Exercise ARM07. Villigen, Switzerland: Paul Scherrer Institut PSI; 2009. 130p. PSI Bericht Nr. 09-07.

available here:
http://www.lib4ri.ch/archive/nebis/PSI_Berichte_000478272/PSI-Bericht_09-07_2D.pdf
or:
https://inis.iaea.org/collection/NCLCollectionStore/_Public/41/030/41030200.pdf

-----------------------------------------------------------

About the data:
- real data, but changed location, date and time information
- made almost manually using QGIS (1), LibreOffice (2) and Notepad++ (3)

- supplied QGIS preview image uses map background from Bing Aerial via OpenLayers plugin

- location of the testing data is now the Vulcano island in Italy:

Vulcano (Sicilian: Vurcanu) or "Vulcan" is a small volcanic island in the Tyrrhenian Sea, about 25 km (16 mi) north of Sicily and located at the southernmost end of the eight Aeolian Islands.[1] The island is 21 km2 (8 sq mi) in area, rises to 501 m (1,644 ft) above sea level, and it contains several volcanic caldera, including one of the four active volcanoes in Italy that are not submarine. The word "volcano" and its equivalent in several European languages derive from the name of this island, which in turn derives from Vulcan, the Roman god of fire.

(source: https://en.wikipedia.org/wiki/Vulcano )

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org