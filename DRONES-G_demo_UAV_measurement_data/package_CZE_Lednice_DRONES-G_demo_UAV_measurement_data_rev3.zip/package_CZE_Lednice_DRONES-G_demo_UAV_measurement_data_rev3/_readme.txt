package_1_Lednice_DRONES-G_demo_UAV_measurement_data

real data from DRONES-G radiation monitoring system for unmanned aerial vehicles
https://nuvia.cz/en/aktuality/437-drones-g---new-product-of-nuvia-cz

About the data
- real data - all the radiation data incl. dose rate values, raw pulses, spectra etc.
- contains raw 1024 channel NaITl spectra
- the radiation data are real but the location and time/date parameters were changed

source:
https://github.com/juhele/opengeodata/tree/master/DRONES-G_demo_UAV_measurement_data

This package contains:

1) measurement data in Pico Envirotec PEI format - can be loaded using PEIView software.
    for more information visit:
    http://picoenvirotec.com/enviro/peiview/
2) raw data - what is inside the PEI binary file...
3) GIS files - GeoPackage file containing vector layer with color style, suitable for GIS application like QGIS, and in addition there is also a simple CSV file


- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org
