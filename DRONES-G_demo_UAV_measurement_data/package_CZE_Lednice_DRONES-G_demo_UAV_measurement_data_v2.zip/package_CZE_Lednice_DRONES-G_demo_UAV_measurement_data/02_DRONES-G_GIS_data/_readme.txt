The data layer 01_20190401_011419_DRONES-G_demo_mereni.gpkg can be easily displayed in QGIS (just drag and drop the file from your file manager to QGIS window), has coordinate system and color style already defined.

The data in OGC GeoPackage ( https://www.geopackage.org ) standard format:

"A GeoPackage (GPKG) is an open, non-proprietary, platform-independent and standards-based data format for geographic information system implemented as a SQLite database container. Defined by the Open Geospatial Consortium (OGC) with the backing of the US military and published in 2014, GeoPackage has seen wide widespread support from various government, commercial, and open source organizations."


(source: Wikipedia https://en.wikipedia.org/wiki/GeoPackage )

The main benefit here is that GeoPackage (GPKG) is one file able to store data, color style, coordinate system data and other information so you just drag and drop the *.gpkg file in empty QGIS window and the layer is loaded with color style applied and without any additional settings required. 

But you also have a simple CSV file there...