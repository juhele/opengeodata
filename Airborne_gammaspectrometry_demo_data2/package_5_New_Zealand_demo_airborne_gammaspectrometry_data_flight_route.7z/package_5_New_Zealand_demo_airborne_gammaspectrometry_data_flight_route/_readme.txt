package_5_New_Zealand_demo_airborne_gammaspectrometry_data_flight_route

This package contains data for flight route. 

1) 01_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon.xyz

- source file created by PEIConvert software by Pico Envirotec
- for more information visit:
http://picoenvirotec.com/enviro/peiconvert/

2) currently it needs manual conversion:

02_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_for_GPX.txt

and

03_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_for_GPX.csv

then to (LibreOffice)

04_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_for_GPX.csv

3) converting the CSV to GPX using GPS Visualizer website:

https://www.gpsvisualizer.com/convert_input?convert_format=gpx&units=metric&form

resulting in "raw" GPX

05_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_raw_GPX.gpx

4) fixing the order of points to get connected flight route using RouteConverter www.routeconverter.com/

06_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_final_GPX.gpx

5) final result 

06_NZ_Tongariro_demo_project_2019-04-01_final_sl_LatLon_final_GPX.gpx

can be used in route planning software like for example Mapy.cz
https://en.mapy.cz
app for 
Android:
https://play.google.com/store/apps/details?id=cz.seznam.mapy
iOS
https://apps.apple.com/cz/app/mapy-cz/id411411020
Windows 10
https://www.windowsphone.com/cs-cz/store/app/mapy-cz/e926fd53-d7cd-4ee7-95c7-c938a5e9a1e5

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org
