﻿MobDose_US_Hawaii_demo

This package contains data from fictional measurement in Kilauea section of Hawaii Volcanoes National Park, Hawaii, USA (en.wikipedia.org/wiki/Kilauea) using the Mob-DOSE (1)(also called PDOSE-3) portable device, in PEI format defined by Pico Envirotec. Can be opened using PEI software like PEIView (2) or PEIConvert (3).

The radiation data are real but the location and time/date parameters were changed.

Also contains "details" folder with exported PEI header and data in CSV and QGIS... folder with full project for QGIS (4) including styled point layer in OGC GeoPackage standard format.

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) http://picoenvirotec.com/enviro/pdose-3/
(2) http://picoenvirotec.com/enviro/peiview/
(3) http://picoenvirotec.com/enviro/peiconvert/
(4) https://qgis.org
(5) https://www.geopackage.org