package_simulated_walk1_Mob-DOSE_B_PDOSE777-8888_2021_04_01_11_04_11

more details:

Simulated radiation monitoring data for training and testing purposes

These datasets could be useful for training - data processing, conversions, creating maps etc. or development / testing new software tools as the data can be freely distributed.

web:
https://github.com/juhele/opengeodata/tree/master/Simulated_radiation_monitoring_data

This package contains simulated walk monitoring "Stromovka"

The data do not contain any values above normal radiation background - the range of the fictional measurement data is 0.101-0.174 microGy/h.

The data is available in native IRIS instrument binary format - PEI file, but also in common CSV file and styled point layer in OGC GeoPackage standard format which can be easily loaded in programs like QGIS (https://qgis.org).

The height data is based on CC BY-SA 4.0 licensed digital terrain model data provided by the Prague Institute of Planning and Development (IPR Prague) (Czech: Institut pl�nov�n� a rozvoje hlavn�ho m�sta Prahy (IPR) ) via www.geoportalpraha.cz.

For more information about the measurement device and data format visit:
http://picoenvirotec.com/enviro/peiconvert/

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz