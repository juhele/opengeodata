Sta�eno z / Downloaded from:
https://github.com/juhele/opengeodata/tree/master/Airborne_monitoring_support