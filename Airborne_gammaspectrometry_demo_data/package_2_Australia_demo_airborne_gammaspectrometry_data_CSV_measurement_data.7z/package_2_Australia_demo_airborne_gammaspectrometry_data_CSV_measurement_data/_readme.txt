package_2_Australia_demo_airborne_gammaspectrometry_data_CSV_measurement_data
source:
https://github.com/juhele/opengeodata/tree/master/Airborne_gammaspectrometry_demo_data

This package contains measurement data in CSV format - column separator is semicolon (;) and decimal separator is comma (,). The header file provides some additional information.

For quick overview:

Galt_m - GPS altitude

UsedAlt_m - height above ground

XCo_m;YCo_m - UTM coordinates in meters (here WGS84 UTM Zone 52S - EPSG:32752)

Lat_deg;Lon_deg - latitude; longitude coordinates in decimal degrees (WGS84 - EPSG:4326)

DosG_nGyph - dose rate in nanoGrays per hour, recalculated to 1 meter above ground

spc_ch001-spc_ch512 - raw spectra

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org