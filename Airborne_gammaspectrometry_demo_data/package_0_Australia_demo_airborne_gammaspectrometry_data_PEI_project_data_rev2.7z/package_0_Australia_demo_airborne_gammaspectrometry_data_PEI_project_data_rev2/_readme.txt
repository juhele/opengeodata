package_0_Australia_demo_airborne_gammaspectrometry_data_PEI_project_data

This package contains data for flight project (including separate files with survey- and tie-lines definitions) in 
Pico Envirotec defined format. Can be opened using PEIConvert software.

for more information visit:
http://picoenvirotec.com/enviro/peiconvert/

- data source for citation etc.:
National Radiation Protection Institute (SURO)
Prague, Czech Republic
www.suro.cz

Contact:
Jan Helebrant
jan.helebrant@suro.cz

Software links:

(1) https://qgis.org
(2) https://www.libreoffice.org
(3) https://notepad-plus-plus.org